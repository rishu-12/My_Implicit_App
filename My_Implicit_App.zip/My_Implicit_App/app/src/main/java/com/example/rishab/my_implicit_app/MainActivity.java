package com.example.rishab.my_implicit_app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        b2=findViewById(R.id.button2);
        b3=findViewById(R.id.button3);
        b4=findViewById(R.id.button4);
    }
    public void process(View view){
        Intent intent = null, chooser=null;
        if(view.getId()==R.id.button){
            intent=new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:19.076,72.8777"));
            chooser=Intent.createChooser(intent,"Launch Map");
            startActivity(chooser);
        }
        if(view.getId()==R.id.button2){
            //intent=new Intent(Intent.ACTION_VIEW);
            //intent.setData(Uri.parse("vnd.youtube:"));
            //chooser=Intent.createChooser(intent,"Launch Youtube");
            //startActivity(chooser);
            Intent LaunchIntent = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
            startActivity(LaunchIntent);
        }
        if(view.getId()==R.id.button3) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.setData(Uri.parse("mail's:"));
            String[] to = {};
            intent.putExtra(Intent.EXTRA_EMAIL, to);
            intent.putExtra(Intent.EXTRA_SUBJECT,"");
            intent.putExtra(Intent.EXTRA_TEXT,"");
            intent.setType("message/rfc822");
            chooser=Intent.createChooser(intent,"Send Email");
            startActivity(chooser);
        }
        if(view.getId()==R.id.button4){
            Toast toast=Toast.makeText(this,"Nothing done yet!!",Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM |Gravity.CENTER,0,0);
            toast.show();
        }
    }
}
